package com.example.aomek.missingpersonsfinder.ui.findandselect;

import android.arch.lifecycle.ViewModel;

public class FindAndSelectViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
